Compile the code in each folder (UDP and TCP) using the command 'make'
then in separate terminal use ./bin/client_udp and ./bin/server_UDP 

The explanations are in the file "Protocole_Description.txt"

The TCP communication did not succeed as we chose a protocol that transports raw binary and we struggled parsing the tcp flux incoming on the server.